# OkCupid-scraper
 A python scraper for OkCpid
