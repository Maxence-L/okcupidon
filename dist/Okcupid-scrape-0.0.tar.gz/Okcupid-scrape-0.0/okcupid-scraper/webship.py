import os
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
import time
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import selenium.common.exceptions as selexcept
# import requests
import re
import pickle
import random
import json
from .dataparser import parse_profile

class WebDrive:

    # Initialize the webdriver, loading target url and the cookies
    def __init__(self, cookies=None):

        def __start_webdriver():
            options = Options()
            options.add_argument('window-size=1200x1000')
            return webdriver.Chrome(chrome_options=options)

        def __load_cookies():
            # Let's try to load user-provided cookies
            if os.path.isfile('cookies.json'):
                try :
                    with open('cookies.json', 'r') as ck :
                        mein_cookies = json.load(ck)
                    print('cookies.json was found')
                    return mein_cookies
                except FileNotFoundError:
                    pass

            # Let's see if we saved previous cookies before
            if os.path.isfile('cookies.pkl'):
                try:
                    mein_cookies = pickle.load(open("cookies.pkl", "rb"))
                    print('Cookies saved by pickle during preceding sessions were found')
                    return mein_cookies
                except EOFError:
                    pass

        self.driver = __start_webdriver()
        self.cookies = __load_cookies()
        self.website = 'https://www.okcupid.com'

    def log_to_ok_cupid(self):
        """This method is used to log to OK_Cupid.
        It searches first for cookies that may have been created before.
        If there are no cookies, it will pass the 2FA using __two_FA()
        and then save the cookies for a quicker log-in later."""

        def __two_fa(self, email=None, pwd=None):
            """This function is used in case where no cookies are provided or OKCupid asks nonetheless
            for a password and a 2FA"""
            """Log to OKCupid with the id provided"""
            print("We'll log in manually to OKCupid, as no valid cookies were found")
            if email == None or pwd == None:
                email = input("Please enter your profile email: ")
                pwd = input("Please enter your password: ")

            # login window access
            self.driver.get(self.website + "/login")
            try:
                WebDriverWait(self.driver, 3).until(
                    EC.presence_of_element_located((By.ID, "username")))
            finally:
                pass
            # Passing the auth info
            self.driver.find_element_by_name("username").send_keys(email)
            self.driver.find_element_by_id('password').send_keys(pwd)

            # Proceed with the login
            self.driver.find_element_by_class_name("login-actions-button").click()
            time.sleep(5)

            # If OKCupid asks for 2FA :
            if self.driver.current_url != 'https://www.okcupid.com/home':
                try:
                    self.driver.find_element_by_class_name("login-actions-button").click()
                    time.sleep(5)

                    # Logging the sms code - prepare to get your SMS
                    code = input('Please enter the six digits (ex : 123456) received by SMS :')
                    code_digits = self.driver.find_elements_by_css_selector("input.code-inputs-digit")

                    for digit in range(6):
                        code_digits[digit].send_keys(code[digit])
                        time.sleep(3)
                except selexcept.NoSuchElementException:
                    pass
                # Clicking on the "next" button
                self.driver.find_element_by_class_name("login-actions-button").click()

            if self.driver.current_url == 'https://www.okcupid.com/home':
                pickle.dump(self.driver.get_cookies(), open("cookies.pkl", "wb"))
                print("Cookies were saved")


        # login window access
        self.driver.get(self.website + "/login")
        try:
            WebDriverWait(self.driver, 3).until(
                EC.presence_of_element_located((By.ID, "username")))
        finally:
            pass

        # Loading cookies if present.
        if self.cookies is not None:
            self.driver.get(self.website)
            for cookie in self.cookies:
                self.driver.add_cookie(cookie)
            print("Cookies were loaded")

        # Close the cookies warning in case it is still here
        try:
            self.driver.find_element_by_id('onetrust-accept-btn-handler').click()
        except selexcept.NoSuchElementException:
            pass

        # Try to get to the home interface
        self.driver.get(self.website+'/home')
        time.sleep(5)
        # If this doesn't work (typically, cookies aren't that fresh), we log-in manually
        cant_connect = self.cookies is None or self.driver.current_url != 'https://www.okcupid.com/home'
        print(self.driver.current_url)
        if cant_connect is True:
            __two_fa(self)
        time.sleep(5)

    def get_current_url(self):
        return self.driver.current_url

    def get_to_full_profile(self):
        try:
            WebDriverWait(self.driver, 5).until(
                EC.presence_of_element_located((By.CLASS_NAME, 'cardsummary')))
            self.driver.find_element_by_link_text('View Profile').click()
        except (selexcept.TimeoutException, selexcept.NoSuchElementException):
            self.driver.get(self.website+'/doubletake')
            
    def acquire_data(self):
        """The main profile scraper :
        acquires all of the personnal data that is on the profile page
        and returns it as a dict"""

        # Open the full essays
        try:
            WebDriverWait(self.driver, 3).until(
                EC.presence_of_element_located(
                    (By.XPATH, '//*[@id="main_content"]/div[3]/div[1]/div[1]/div/button/span')))
            self.driver.find_element_by_xpath('//*[@id="main_content"]/div[3]/div[1]/div[1]/div/button/span').click()
        except (selexcept.NoSuchElementException, selexcept.TimeoutException):
            pass
        with open('profile.html', 'w') as file:
            file.write(self.driver.page_source)
            file.close()

        # Parse the profile
        profile_id = re.search('(?<=\/)(\d*?)(?=\?)', self.driver.current_url).group(0)
        data = parse_profile(profile_id=profile_id, html_page=self.driver.page_source)

        return data

    def new_profile(self, decision):
        """Brings the driver to a new profile"""
        WebDriverWait(self.driver, 3).until(
            EC.presence_of_element_located((By.ID, "like-button")))
        if decision:
            self.driver.\
                find_element_by_xpath('/html/body/div[1]/main/div[1]/div[2]/div/div/div[3]/span/div/button[2]').\
                click()
            self.driver.get('https://www.okcupid.com/doubletake')
        else :
            self.driver.\
            find_element_by_xpath("/html/body/div[1]/main/div[1]/div[2]/div/div/div[3]/span/div/button[1]").\
            click()

    def answer_profile_questions(self, okc_db):
        """Answers to unanswered questions in order to """

        # Get to questions page
        profile_id = re.search('(?<=\/)(\d*?)(?=\?)', self.driver.current_url).group(0)
        questions_url = f"https://www.okcupid.com/profile/{profile_id}/questions?cf=profile%20match%20score"
        self.driver.get(questions_url)

        for i in range(0,3):
            # Show unanswered questions
            WebDriverWait(self.driver, 10).until(
                EC.presence_of_element_located((By.CLASS_NAME, 'profile-questions-filter')))

            time.sleep(4)
            self.driver.\
                find_element_by_xpath("/html/body/div[1]/main/div[1]/div[2]/div/div[1]/div/div[2]/div/button[3]/span[1]").\
                click()
            time.sleep(2)

            print(self.driver.find_elements_by_xpath("//span[@class='profile-questions-filter-count']")[2].text)
            if self.driver.find_elements_by_xpath("//span[@class='profile-questions-filter-count']")[2].text == '0':
                print('No unanswered questions')
                return

            time.sleep(4)
            # Answer to questions
            question = self.driver.find_elements_by_class_name('profile-question')[0]
            question.click()
            print('click')


            WebDriverWait(self.driver, 10).until(
                EC.presence_of_element_located((By.CLASS_NAME,"questionspage-multipartquestion-answers-answer-label")))
            time.sleep(3)
            possible_answers = list()
            for choice in self.driver.find_elements_by_class_name(
                    "questionspage-multipartquestion-answers-answer-label"):
                possible_answers.append(choice.text)

            rand_choice = random.choice(possible_answers)
            print(possible_answers)
            for choice in self.driver.find_elements_by_class_name(
                    "questionspage-multipartquestion-answers-answer-label"):
                if choice.text == rand_choice:
                    choice.click()
                    break

            for choice in self.driver.find_elements_by_class_name(
                    "questionspage-multipartquestion-acceptableanswers-answer-label"):
                if choice.text == rand_choice:
                    choice.click()
                    break

            rand_choice = random.choice(['A little', 'Somewhat', 'Very'])

            for button in self.driver. \
                    find_elements_by_xpath(
                '//*[@id="OkModal"]/div/div[1]/div/div/div/div[2]/div/div/div[1]/div[3]/div/div/button'):
                if button.text == rand_choice:
                    button.click()
                    break
            question_text = self.driver.find_element_by_class_name('questionspage-multipartquestion-questiontext').text

            okc_db.save_question_type_to_db(question=question_text, answers=possible_answers)

            time.sleep(2)
            self.driver. \
                find_element_by_xpath("//*[@id='OkModal']/div/div[1]/div/div/div/div[2]/div/div/div[2]/button[2]").\
                click()
        okc_db.close()






    def answer_question_bis(self):
        self.driver.get('https://www.okcupid.com/profile/14203747758925873032/questions?cf=discovery')
        WebDriverWait(self.driver, 10).until(
            EC.presence_of_element_located((By.XPATH, '/html/body/div[1]/main/div[1]/div[2]/div/div[2]/div[1]/span/span')))
        self.driver.\
            find_element_by_xpath('/html/body/div[1]/main/div[1]/div[2]/div/div[2]/div[1]/div/button[2]').\
            click()


        for i in range(0,500):
            try :
                time.sleep(3)
                possible_answers = list()
                for choice in self.driver.find_elements_by_class_name("questionspage-multipartquestion-answers-answer-label"):
                    possible_answers.append(choice.text)

                rand_choice = random.choice(possible_answers)

                for choice in self.driver.find_elements_by_class_name("questionspage-multipartquestion-answers-answer-label"):
                    if choice.text == rand_choice:
                        choice.click()
                        break

                for choice in self.driver.find_elements_by_class_name("questionspage-multipartquestion-acceptableanswers-answer-label"):
                    if choice.text == rand_choice:
                        choice.click()
                        break

                rand_choice = random.choice(['A little', 'Somewhat', 'Very'])

                for button in self.driver.\
                    find_elements_by_xpath('//*[@id="OkModal"]/div/div[1]/div/div/div/div[2]/div/div/div[1]/div[3]/div/div/button'):
                    if button.text == rand_choice:
                        button.click()
                        break

                question_text = self.driver.find_element_by_class_name('questionspage-multipartquestion-questiontext').text

                #okc_db.save_question_type_to_db(question=question_text, answers=possible_answers)

                self.driver.\
                    find_element_by_xpath("//*[@id='OkModal']/div/div[1]/div/div/div/div[2]/div/div/div[2]/button[2]").\
                    click()
            except :
                self.driver.get('https://www.okcupid.com/profile/14203747758925873032/questions?cf=discovery')
                WebDriverWait(self.driver, 10).until(
                    EC.presence_of_element_located(
                        (By.XPATH, '/html/body/div[1]/main/div[1]/div[2]/div/div[2]/div[1]/span/span')))
                self.driver. \
                    find_element_by_xpath('/html/body/div[1]/main/div[1]/div[2]/div/div[2]/div[1]/div/button[2]'). \
                    click()

        okc_db.close()

    def save_profile_answers(self, id):
        questions_url = f"https://www.okcupid.com/profile/{id}/questions?cf=profile%20match%20score"
        if self.get_current_url() != questions_url:
            self.driver.get(questions_url)

            scroll_pause_time = 0.5

            # Get scroll height
            last_height = self.driver.execute_script("return document.body.scrollHeight")

            while True:
                # Scroll down to bottom
                self.driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")

                # Wait to load page
                time.sleep(scroll_pause_time)

                # Calculate new scroll height and compare with last scroll height
                new_height = self.driver.execute_script("return document.body.scrollHeight")
                if new_height == last_height:
                    break
                last_height = new_height

        time.sleep(0.5)
        #for question_box in self.driver.find_elements_by_class_name("profile-questions"):
        #   question =

