import requests
import random
import time
from WebDrive import WebDrive
from database import dataBase


# https://yadim.dismail.de/?diecki81@yadim.dismail.de



okc_db = dataBase('okcupid-scraper/okc_db')

usr = 'zexc80@yadim.dismail.de'
mdp = 'MyWebScrapper'
url_sms = 'http://5ec7b7357a98.ngrok.io'
website = "https://www.okcupid.com/login"

# Start ngrok with 'ngrok 5000' command in shell

if usr is None:
    usr = input('Please input your username : ')

if mdp is None :
    mdp = input('Please input your password : ')

if url_sms is None:
    url_sms = input('Please input the url of the server running Flask (possibly with Ngrok) : ')

my_scrapper = WebDrive(usr, mdp, url_sms, website)

# Logging in
my_scrapper.log_to_ok_cupid()
my_scrapper.get_current_url()

# Shutdown the server
print('Shutting down Flask...')
requests.get(url_sms+'/shutdown')

# Getting to the profile

for i in range(0,1):
    time.sleep(1)
    # Getting to the profile
    my_scrapper.get_to_full_profile()
    time.sleep(1)
    print(my_scrapper.get_current_url())
    # Acquiring data
    decision = bool(random.randint(0, 1))
    profile_data = my_scrapper.acquire_data()
    okc_db.save_profile_to_db(dict_data=profile_data, decision=decision)
    time.sleep(1)
    # Next profile
    my_scrapper.new_profile(decision=decision)
    time.sleep(1)


# Close the db connection
print("closing DB")
okc_db.close()

# # Enter quickmatch mode
# enter_profile(driver)
#
# profile_db = sqlite3.con
